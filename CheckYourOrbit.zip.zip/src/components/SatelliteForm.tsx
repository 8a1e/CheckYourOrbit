import React, { useState } from 'react';
import { Satellite } from '../types/Satellite';

interface Props {
  onAdd: (sat: Satellite) => void;
}

const SatelliteForm: React.FC<Props> = ({ onAdd }) => {
  const [name, setName] = useState('');
  const [altitude, setAltitude] = useState(500);
  const [inclination, setInclination] = useState(45);
  const [velocity, setVelocity] = useState(7.8);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newSat: Satellite = {
      id: Date.now().toString(),
      name,
      altitude,
      inclination,
      velocity,
    };
    onAdd(newSat);
    setName('');
  };

  return (
    <form
      onSubmit={handleSubmit}
      style={{
        backgroundColor: '#eef4ff',
        padding: '20px',
        borderRadius: '10px',
        maxWidth: '400px',
        margin: '20px auto',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
      }}
    >
      <h3 style={{ textAlign: 'center', marginBottom: '20px' }}>🛰️ Add Satellite</h3>

      <label><strong>Name</strong></label>
      <input
        value={name}
        onChange={e => setName(e.target.value)}
        placeholder="e.g. Hubble"
        required
        style={{ width: '100%', padding: '8px', marginBottom: '12px' }}
      />

      <label><strong>Altitude (km)</strong></label>
      <input
        type="number"
        value={altitude}
        onChange={e => setAltitude(+e.target.value)}
        placeholder="e.g. 500"
        style={{ width: '100%', padding: '8px', marginBottom: '12px' }}
      />

      <label><strong>Inclination (°)</strong></label>
      <input
        type="number"
        value={inclination}
        onChange={e => setInclination(+e.target.value)}
        placeholder="e.g. 45"
        style={{ width: '100%', padding: '8px', marginBottom: '12px' }}
      />

      <label><strong>Velocity (km/s)</strong></label>
      <input
        type="number"
        value={velocity}
        onChange={e => setVelocity(+e.target.value)}
        placeholder="e.g. 7.8"
        style={{ width: '100%', padding: '8px', marginBottom: '20px' }}
      />

      <button
        type="submit"
        style={{
          width: '100%',
          padding: '10px',
          backgroundColor: '#007bff',
          color: '#fff',
          border: 'none',
          borderRadius: '5px',
          cursor: 'pointer',
        }}
      >
        Add Satellite
      </button>
    </form>
  );
};

export default SatelliteForm;
