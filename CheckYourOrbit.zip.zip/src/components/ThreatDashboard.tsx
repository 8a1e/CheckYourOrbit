import React from 'react';
import { Satellite } from '../types/Satellite';
import { detectThreats } from '../utils/mockApi';

interface Props {
  satellites: Satellite[];
  onRemove: (id: string) => void;
}

const ThreatDashboard: React.FC<Props> = ({ satellites, onRemove }) => {
  const results = detectThreats(satellites);

  return (
    <div
      style={{
        backgroundColor: '#fefefe',
        padding: '20px',
        borderRadius: '10px',
        maxWidth: '600px',
        margin: '20px auto',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
      }}
    >
      <h3 style={{ textAlign: 'center', marginBottom: '20px' }}>🚨 Threat Dashboard</h3>
      {results.map(({ satellite, threats, action }) => (
        <div
          key={satellite.id}
          style={{
            border: '1px solid #ccc',
            borderRadius: '8px',
            padding: '12px',
            marginBottom: '16px',
            backgroundColor: '#f9f9ff',
          }}
        >
          <strong>{satellite.name}</strong>
          <div style={{ margin: '10px 0' }}>
            <div style={{ fontSize: '14px', marginBottom: '4px' }}>Altitude: {satellite.altitude} km</div>
            <div
              style={{
                height: '10px',
                width: '100%',
                backgroundColor: '#e0e0e0',
                borderRadius: '5px',
                overflow: 'hidden',
              }}
            >
              <div
                style={{
                  height: '100%',
                  width: `${Math.min(satellite.altitude / 10, 100)}%`,
                  backgroundColor: satellite.altitude > 600 ? '#ff4d4d' : '#4caf50',
                  transition: 'width 0.5s ease',
                }}
              />
            </div>
          </div>
          <p><strong>Threats:</strong> {threats.length ? threats.join(', ') : 'None'}</p>
          <p><strong>Recommended Action:</strong> {action}</p>
          <button
            onClick={() => onRemove(satellite.id)}
            style={{
              marginTop: '10px',
              backgroundColor: '#ff4d4d',
              color: 'white',
              padding: '6px 12px',
              border: 'none',
              borderRadius: '6px',
              cursor: 'pointer',
            }}
          >
            🗑️ Delete Satellite
          </button>
        </div>
      ))}
    </div>
  );
};

export default ThreatDashboard;
