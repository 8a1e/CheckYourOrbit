import React from 'react';
import { Satellite } from '../types/Satellite';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { ChartData, ChartOptions } from 'chart.js';

ChartJS.register(LineElement, CategoryScale, LinearScale, PointElement, Title, Tooltip, Legend);

interface Props {
  satellites: Satellite[];
}

const AltitudeChart: React.FC<Props> = ({ satellites }) => {
  const data: ChartData<'line'> = {
    labels: satellites.map((s) => s.name),
    datasets: [
      {
        label: 'Altitude (km)',
        data: satellites.map((s) => s.altitude),
        borderColor: 'rgba(0, 123, 255, 1)',
        backgroundColor: 'rgba(0, 123, 255, 0.2)',
        fill: true,
        tension: 0.3,
      },
    ],
  };

  const options: ChartOptions<'line'> = {
    responsive: true,
    scales: {
      y: {
        beginAtZero: true,
        title: {
          display: true,
          text: 'Altitude (km)',
        },
      },
      x: {
        title: {
          display: true,
          text: 'Satellite Name',
        },
      },
    },
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: '📈 Altitude Tracker',
      },
    },
  };

  return (
    <div style={{ maxWidth: '600px', margin: '20px auto' }}>
      <h3 style={{ textAlign: 'center' }}>📈 Altitude Tracker</h3>
      <Line data={data} options={options} />
    </div>
  );
};

export default AltitudeChart;
