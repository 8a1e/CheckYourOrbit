import { Satellite } from '../types/Satellite';

export function detectThreats(satellites: Satellite[]) {
  return satellites.map((sat) => {
    const threats: string[] = [];
    let action = 'Maintain current orbit';

    if (sat.altitude > 600) {
      threats.push('☀️ CME Risk');
      const reduction = sat.altitude - 600;
      action = `Reduce altitude by ${reduction.toFixed(0)} km`;
    }

    if (sat.inclination > 50) {
      threats.push('🪨 Conjunction Risk');
      const adjustment = sat.inclination - 50;
      action = threats.length > 1
        ? `${action}; Adjust inclination by ${adjustment.toFixed(1)}°`
        : `Adjust inclination by ${adjustment.toFixed(1)}°`;
    }

    return { satellite: sat, threats, action };
  });
}
