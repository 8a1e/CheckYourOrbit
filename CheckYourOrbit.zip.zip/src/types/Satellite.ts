export interface Satellite {
  id: string;
  name: string;
  altitude: number;
  inclination: number;
  velocity: number;
}
