import React, { useState } from 'react';
import SatelliteForm from './components/SatelliteForm';
import AltitudeChart from './components/AltitudeChart';
import ThreatDashboard from './components/ThreatDashboard';
import { Satellite } from './types/Satellite';

function App() {
  const [satellites, setSatellites] = useState<Satellite[]>([]);

  const addSatellite = (sat: Satellite) => {
    setSatellites([...satellites, sat]);
  };

  const removeSatellite = (id: string) => {
    setSatellites(satellites.filter((s) => s.id !== id));
  };

  const clearSatellites = () => {
    setSatellites([]);
  };

  return (
    <div style={{ fontFamily: 'Arial, sans-serif', backgroundColor: 'white', minHeight: '100vh', padding: '20px' }}>
      <h1 style={{ textAlign: 'center' }}>🛰️ Check Your Orbit</h1>
      <SatelliteForm onAdd={addSatellite} />
      <div style={{ textAlign: 'center', marginBottom: '20px' }}>
        <button onClick={clearSatellites} style={{ backgroundColor: '#ff4d4d', color: 'white', padding: '8px 16px', borderRadius: '6px' }}>
          🗑️ Delete All Satellites
        </button>
      </div>
      <AltitudeChart satellites={satellites} />
      <ThreatDashboard satellites={satellites} onRemove={removeSatellite} />
    </div>
  );
}

export default App;
